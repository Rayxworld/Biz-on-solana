
BizFi prediction market contract handoff (Solana Devnet)

Scope (on-chain):
- Create market, accept bets, resolve, pay winners
Scope (off-chain):
- Token launches on other chains, AI agent workflow, marketing

Program:
- Name: bizfi_market
- Program ID: 5JUtUiusEUzwgub1LTztjGJ1h2krpzqBaVfQrEHHwJbr
- Deploy tx: 52q7dqhxDTsmQ8toyxxKCiBiQsfN1R4vaNodV4DE2QhP8jbycnwP119dTrCmBiSN5SuPAjvEQo6HFaFbP4xjJbkK

Artifacts:
- Source: lib.rs
- IDL: bizfi_market.json
- PDA spec: PDA_SPEC.md
- Call examples: CALL_EXAMPLES.md
- Deployment checklist: DEPLOYMENT_CHECKLIST.md

Instructions:
1) initialize_market(market_id, question, duration)
2) place_bet(amount, bet_on_yes)
3) resolve_market(outcome)
4) claim_winnings()

PDA seeds:
- market: ["market", market_id]
- position: ["position", market_id, user_pubkey]
- vault: ["vault", market_id]
- vault_authority: ["vault_authority", market_id]

Test transactions:
- initialize_market: 2PtWJCwGzfPkCCLtQSD5JVpqhRQFVmEcS57xeaQLVsHbLjMVJJn2vyy15wd1TcZPGb8PxkkP4SpZ5aeuGRBDBLL
- place_bet: 4zGW8xtwb6G76sJUt5NRV2SfkMoPcXAKZ3XunBECKtiGndr2GyLQWUkHPk1UfYQvRxTWq18MLEFGUWzcL1VcFxXT
- resolve_market: 9RMLSHgtytHqeLbJ4R5NyPMhnVsXLCZ137XoHXvwaccvfzwTmW1S2jEcohnVXUuYLYLYr7fpsJCSEDrhxxq7UYf
- claim_winnings: 2aGMcMn71uzL56nqD9VT9S729XTgxYAG6DxrKDfh3YgrpioZGyqfkYQqb142a399LQyirG3P1zqkK99SZopHiUks

Known limitations:
- Manual resolution by creator
- No oracle integration
```
