# PDA Specification

## Seed Rules
Use these exact seeds:

1. Market PDA
- Label: `market`
- Seeds: `["market", market_id]`
- Encoding:
  - `"market"` as bytes
  - `market_id` as UTF-8 bytes

2. User Position PDA
- Label: `position`
- Seeds: `["position", market_id, user_pubkey]`
- Encoding:
  - `"position"` as bytes
  - `market_id` as UTF-8 bytes
  - `user_pubkey` as 32-byte pubkey

3. Vault PDA
- Label: `vault`
- Seeds: `["vault", market_id]`
- Encoding:
  - `"vault"` as bytes
  - `market_id` as UTF-8 bytes

## Copy-Paste Reference
```rust
// Market PDA
let (market_pda, market_bump) = Pubkey::find_program_address(
    &[b"market", market_id.as_bytes()],
    &program_id,
);

// Position PDA
let (position_pda, position_bump) = Pubkey::find_program_address(
    &[b"position", market_id.as_bytes(), user_pubkey.as_ref()],
    &program_id,
);

// Vault PDA
let (vault_pda, vault_bump) = Pubkey::find_program_address(
    &[b"vault", market_id.as_bytes()],
    &program_id,
);
```

## Bump Handling
- Store bumps on account where needed.
- Use signer seeds for PDA-authorized token transfers:
```rust
let signer_seeds: &[&[u8]] = &[b"market", market_id.as_bytes(), &[market_bump]];
```

## Final Confirmation
- Program ID used for PDA derivation: `<PASTE_PROGRAM_ID>`
- Seed schema version: `v1`
