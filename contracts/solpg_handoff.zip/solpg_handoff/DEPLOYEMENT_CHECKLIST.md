# Deprecated Filename

This file name has a typo.

Use this file instead:
- `DEPLOYMENT_CHECKLIST.md`

If you already shared this filename with someone, keep both files for compatibility.
